﻿using System.Windows.Forms;

namespace Pyörärekisteri
{
    internal class Formkirjaudu : Form
    {
    }
}