﻿using System;
using System.IO;
using System.Collections;
using System.Data.SqlClient;
using System.Data.SQLite;
using System.Security.Cryptography;
using System.Text;
using System.Windows.Forms;
using Pyörärekisteri;
using static Pyörärekisteri.Form1;

namespace pyörärekisteri2
{
    public partial class Formkirjaudu : Form
    {
        private string dbPath;
        private DatabaseHelper dbHelper;

        public Formkirjaudu()
        {
            InitializeComponent();
            dbPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Database.db");
            dbHelper = new DatabaseHelper(dbPath);
        }


        private void buttonkirjaudu_Click(object sender, EventArgs e)
        {
            string username = txtktnimi.Text;
            string password = txtsalasana.Text;

            string hashedPasswordFromDB = GetHashedPasswordFromDatabase(username);
            string hashedUsernameFromDB = GetHashedUsernameFromDatabase(username);

            if (password == hashedPasswordFromDB && username == hashedUsernameFromDB)
            {
                MessageBox.Show("Login successful!");

                Form1 NewForm = new Form1();
                NewForm.Show();
                this.Dispose(false);
            }
            else
            {
                MessageBox.Show("Invalid username or password.");
            }
        }

        private string GetHashedPasswordFromDatabase(string username)
        {
            string hashedPassword = null;

            using (var connection = new SQLiteConnection(dbHelper.ConnectionString))
            {
                connection.Open();

                string query = "SELECT Salasana FROM Tunnukset WHERE Nimi = @Nimi";
                using (SQLiteCommand command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Nimi", username);
                    hashedPassword = command.ExecuteScalar() as string;
                }
            }
            return hashedPassword;
        }

        private string GetHashedUsernameFromDatabase(string username)
        {
            string hashedUsername = null;

            using (var connection = new SQLiteConnection(dbHelper.ConnectionString))
            {
                connection.Open();

                string query = "SELECT Nimi FROM Tunnukset WHERE Nimi = @Nimi";
                using (SQLiteCommand command = new SQLiteCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Nimi", username);
                    hashedUsername = command.ExecuteScalar() as string;
                }
            }
            return hashedUsername;
        }
    }

    public class DatabaseHelper
    {
        public string ConnectionString { get; private set; }

        public DatabaseHelper(string dbPath)
        {
            ConnectionString = $"Data Source=|DataDirectory|{Path.GetFileName(dbPath)};Version=3;";
        }

    }
}