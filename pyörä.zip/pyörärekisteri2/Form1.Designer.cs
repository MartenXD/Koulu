﻿
namespace Pyörärekisteri
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonmuokkaa = new System.Windows.Forms.Button();
            buttontallenna = new System.Windows.Forms.Button();
            buttonpoista = new System.Windows.Forms.Button();
            txtomistaja = new System.Windows.Forms.TextBox();
            txtsähkö = new System.Windows.Forms.TextBox();
            txtnumero = new System.Windows.Forms.TextBox();
            txtpuhe = new System.Windows.Forms.TextBox();
            txthinta = new System.Windows.Forms.TextBox();
            Omistaja = new System.Windows.Forms.Label();
            Sähköposti = new System.Windows.Forms.Label();
            label = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            txtsala = new System.Windows.Forms.TextBox();
            label1 = new System.Windows.Forms.Label();
            listBoxBikes = new System.Windows.Forms.ListBox();
            txtmomistaja = new System.Windows.Forms.TextBox();
            label2 = new System.Windows.Forms.Label();
            txtmsähkö = new System.Windows.Forms.TextBox();
            txtmnumero = new System.Windows.Forms.TextBox();
            txtmpuhe = new System.Windows.Forms.TextBox();
            txtmhinta = new System.Windows.Forms.TextBox();
            checkBox1 = new System.Windows.Forms.CheckBox();
            bntsalasana = new System.Windows.Forms.Button();
            SuspendLayout();
            // 
            // buttonmuokkaa
            // 
            buttonmuokkaa.Location = new System.Drawing.Point(184, 297);
            buttonmuokkaa.Name = "buttonmuokkaa";
            buttonmuokkaa.Size = new System.Drawing.Size(86, 50);
            buttonmuokkaa.TabIndex = 0;
            buttonmuokkaa.Text = "Päivitä muokkaus";
            buttonmuokkaa.UseVisualStyleBackColor = true;
            buttonmuokkaa.Visible = false;
            buttonmuokkaa.Click += buttonmuokkaa_Click;
            // 
            // buttontallenna
            // 
            buttontallenna.Location = new System.Drawing.Point(184, 298);
            buttontallenna.Name = "buttontallenna";
            buttontallenna.Size = new System.Drawing.Size(86, 50);
            buttontallenna.TabIndex = 2;
            buttontallenna.Text = "Tallenna";
            buttontallenna.UseVisualStyleBackColor = true;
            buttontallenna.Click += buttontallenna_Click_1;
            // 
            // buttonpoista
            // 
            buttonpoista.Location = new System.Drawing.Point(516, 362);
            buttonpoista.Name = "buttonpoista";
            buttonpoista.Size = new System.Drawing.Size(87, 50);
            buttonpoista.TabIndex = 3;
            buttonpoista.Text = "Poista";
            buttonpoista.UseVisualStyleBackColor = true;
            buttonpoista.Click += buttonpoista_Click;
            // 
            // txtomistaja
            // 
            txtomistaja.Location = new System.Drawing.Point(18, 188);
            txtomistaja.Name = "txtomistaja";
            txtomistaja.Size = new System.Drawing.Size(80, 23);
            txtomistaja.TabIndex = 4;
            // 
            // txtsähkö
            // 
            txtsähkö.Location = new System.Drawing.Point(190, 188);
            txtsähkö.Name = "txtsähkö";
            txtsähkö.Size = new System.Drawing.Size(80, 23);
            txtsähkö.TabIndex = 5;
            // 
            // txtnumero
            // 
            txtnumero.Location = new System.Drawing.Point(18, 250);
            txtnumero.Name = "txtnumero";
            txtnumero.Size = new System.Drawing.Size(80, 23);
            txtnumero.TabIndex = 6;
            // 
            // txtpuhe
            // 
            txtpuhe.Location = new System.Drawing.Point(190, 250);
            txtpuhe.Name = "txtpuhe";
            txtpuhe.Size = new System.Drawing.Size(80, 23);
            txtpuhe.TabIndex = 7;
            // 
            // txthinta
            // 
            txthinta.Location = new System.Drawing.Point(18, 316);
            txthinta.Name = "txthinta";
            txthinta.Size = new System.Drawing.Size(80, 23);
            txthinta.TabIndex = 8;
            // 
            // Omistaja
            // 
            Omistaja.AutoSize = true;
            Omistaja.Location = new System.Drawing.Point(18, 170);
            Omistaja.Name = "Omistaja";
            Omistaja.Size = new System.Drawing.Size(54, 15);
            Omistaja.TabIndex = 9;
            Omistaja.Text = "Omistaja";
            // 
            // Sähköposti
            // 
            Sähköposti.AutoSize = true;
            Sähköposti.Location = new System.Drawing.Point(190, 170);
            Sähköposti.Name = "Sähköposti";
            Sähköposti.Size = new System.Drawing.Size(65, 15);
            Sähköposti.TabIndex = 10;
            Sähköposti.Text = "Sähköposti";
            // 
            // label
            // 
            label.AutoSize = true;
            label.Location = new System.Drawing.Point(18, 232);
            label.Name = "label";
            label.Size = new System.Drawing.Size(120, 15);
            label.TabIndex = 11;
            label.Text = "Pyörän runkonumero";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(190, 232);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(47, 15);
            label4.TabIndex = 12;
            label4.Text = "Puhelin";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(18, 298);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(36, 15);
            label5.TabIndex = 13;
            label5.Text = "Hinta";
            // 
            // txtsala
            // 
            txtsala.Location = new System.Drawing.Point(12, 50);
            txtsala.Name = "txtsala";
            txtsala.Size = new System.Drawing.Size(80, 23);
            txtsala.TabIndex = 15;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(12, 32);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(134, 15);
            label1.TabIndex = 16;
            label1.Text = "Kirjaudu muokkaukseen";
            // 
            // listBoxBikes
            // 
            listBoxBikes.FormattingEnabled = true;
            listBoxBikes.ItemHeight = 15;
            listBoxBikes.Location = new System.Drawing.Point(362, 88);
            listBoxBikes.Name = "listBoxBikes";
            listBoxBikes.Size = new System.Drawing.Size(554, 259);
            listBoxBikes.TabIndex = 17;
            // 
            // txtmomistaja
            // 
            txtmomistaja.Location = new System.Drawing.Point(18, 188);
            txtmomistaja.Name = "txtmomistaja";
            txtmomistaja.Size = new System.Drawing.Size(80, 23);
            txtmomistaja.TabIndex = 18;
            txtmomistaja.Visible = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(114, 154);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(56, 15);
            label2.TabIndex = 19;
            label2.Text = "Muokkaa";
            label2.Visible = false;
            // 
            // txtmsähkö
            // 
            txtmsähkö.Location = new System.Drawing.Point(190, 188);
            txtmsähkö.Name = "txtmsähkö";
            txtmsähkö.Size = new System.Drawing.Size(80, 23);
            txtmsähkö.TabIndex = 20;
            txtmsähkö.Visible = false;
            // 
            // txtmnumero
            // 
            txtmnumero.Location = new System.Drawing.Point(18, 250);
            txtmnumero.Name = "txtmnumero";
            txtmnumero.Size = new System.Drawing.Size(80, 23);
            txtmnumero.TabIndex = 21;
            txtmnumero.Visible = false;
            // 
            // txtmpuhe
            // 
            txtmpuhe.Location = new System.Drawing.Point(190, 250);
            txtmpuhe.Name = "txtmpuhe";
            txtmpuhe.Size = new System.Drawing.Size(80, 23);
            txtmpuhe.TabIndex = 22;
            txtmpuhe.Visible = false;
            // 
            // txtmhinta
            // 
            txtmhinta.Location = new System.Drawing.Point(18, 316);
            txtmhinta.Name = "txtmhinta";
            txtmhinta.Size = new System.Drawing.Size(80, 23);
            txtmhinta.TabIndex = 23;
            txtmhinta.Visible = false;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new System.Drawing.Point(214, 54);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new System.Drawing.Size(81, 19);
            checkBox1.TabIndex = 24;
            checkBox1.Text = "Muokkaus";
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.Visible = false;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // bntsalasana
            // 
            bntsalasana.Location = new System.Drawing.Point(114, 50);
            bntsalasana.Name = "bntsalasana";
            bntsalasana.Size = new System.Drawing.Size(75, 23);
            bntsalasana.TabIndex = 25;
            bntsalasana.Text = "Kirjaudu";
            bntsalasana.UseVisualStyleBackColor = true;
            bntsalasana.Click += bntsalasana_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(964, 462);
            Controls.Add(bntsalasana);
            Controls.Add(checkBox1);
            Controls.Add(txtmhinta);
            Controls.Add(txtmpuhe);
            Controls.Add(txtmnumero);
            Controls.Add(txtmsähkö);
            Controls.Add(label2);
            Controls.Add(txtmomistaja);
            Controls.Add(listBoxBikes);
            Controls.Add(label1);
            Controls.Add(txtsala);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label);
            Controls.Add(Sähköposti);
            Controls.Add(Omistaja);
            Controls.Add(txthinta);
            Controls.Add(txtpuhe);
            Controls.Add(txtnumero);
            Controls.Add(txtsähkö);
            Controls.Add(txtomistaja);
            Controls.Add(buttonpoista);
            Controls.Add(buttontallenna);
            Controls.Add(buttonmuokkaa);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button buttonmuokkaa;
        private System.Windows.Forms.Button buttontallenna;
        private System.Windows.Forms.Button buttonpoista;
        private System.Windows.Forms.TextBox txtomistaja;
        private System.Windows.Forms.TextBox txtsähkö;
        private System.Windows.Forms.TextBox txtnumero;
        private System.Windows.Forms.TextBox txtpuhe;
        private System.Windows.Forms.TextBox txthinta;
        private System.Windows.Forms.Label Omistaja;
        private System.Windows.Forms.Label Sähköposti;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtsala;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listBoxBikes;
        private System.Windows.Forms.TextBox txtmomistaja;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtmsähkö;
        private System.Windows.Forms.TextBox txtmnumero;
        private System.Windows.Forms.TextBox txtmpuhe;
        private System.Windows.Forms.TextBox txtmhinta;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button bntsalasana;
    }
}

