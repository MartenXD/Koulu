﻿namespace pyörärekisteri2
{
    partial class Formkirjaudu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            buttonkirjaudu = new System.Windows.Forms.Button();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            txtsalasana = new System.Windows.Forms.TextBox();
            txtktnimi = new System.Windows.Forms.TextBox();
            SuspendLayout();
            // 
            // buttonkirjaudu
            // 
            buttonkirjaudu.Location = new System.Drawing.Point(51, 183);
            buttonkirjaudu.Name = "buttonkirjaudu";
            buttonkirjaudu.Size = new System.Drawing.Size(75, 23);
            buttonkirjaudu.TabIndex = 0;
            buttonkirjaudu.Text = "Kirjaudu";
            buttonkirjaudu.UseVisualStyleBackColor = true;
            buttonkirjaudu.Click += buttonkirjaudu_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(43, 39);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(73, 15);
            label1.TabIndex = 1;
            label1.Text = "Käyttäjänimi";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(43, 97);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(52, 15);
            label2.TabIndex = 2;
            label2.Text = "Salasana";
            // 
            // txtsalasana
            // 
            txtsalasana.Location = new System.Drawing.Point(43, 115);
            txtsalasana.Name = "txtsalasana";
            txtsalasana.Size = new System.Drawing.Size(100, 23);
            txtsalasana.TabIndex = 3;
            // 
            // txtktnimi
            // 
            txtktnimi.Location = new System.Drawing.Point(43, 57);
            txtktnimi.Name = "txtktnimi";
            txtktnimi.Size = new System.Drawing.Size(100, 23);
            txtktnimi.TabIndex = 4;
            // 
            // Formkirjaudu
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(213, 343);
            Controls.Add(txtktnimi);
            Controls.Add(txtsalasana);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(buttonkirjaudu);
            Name = "Formkirjaudu";
            Text = "Formkirjaudu";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button buttonkirjaudu;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtsalasana;
        private System.Windows.Forms.TextBox txtktnimi;
    }
}