﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Data.SQLite;
using System.IO;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Diagnostics;
using System.Text;
using System.Text.RegularExpressions;

namespace Pyörärekisteri
{

    public partial class Form1 : Form
    {
        private string dbPath;

        public class BikeEntry
        {
            public int Id { get; set; }
            public string OwnerName { get; set; }
            public double FrameNumber { get; set; }
            public double PhoneNumber { get; set; }
            public string Email { get; set; }
            public double Price { get; set; }
            public override string ToString()
            {
                return $"Omistajan nimi: {OwnerName} Runkonumero: {FrameNumber} Puhelin numero: {PhoneNumber} Sähköposti: {Email} Hinta: {Price}";
            }
        }

        private void buttonmuokkaa_Click(object sender, EventArgs e)
        {
            try
            {
                if (listBoxBikes.SelectedItem is BikeEntry selectedEntry)
                {
                    string newOmistaja = txtmomistaja.Text;
                    selectedEntry.OwnerName = newOmistaja;

                    string newSähkö = txtmsähkö.Text;
                    selectedEntry.Email = newSähkö;

                    int newHinta = int.Parse(txtmhinta.Text);
                    selectedEntry.Price = newHinta;

                    int newNumero = int.Parse(txtmnumero.Text);
                    selectedEntry.FrameNumber = newNumero;

                    int newPuhelin = int.Parse(txtmpuhe.Text);
                    selectedEntry.PhoneNumber = newPuhelin;


                    dbHelper.UpdateBikeEntry(selectedEntry);
                    LoadDatabaseContent();
                    MessageBox.Show("Tiedot muokattu onnistuneesti.");

                    txtmomistaja.Text = "";
                    txtmhinta.Text = "";
                    txtmnumero.Text = "";
                    txtmpuhe.Text = "";
                    txtmsähkö.Text = "";
                }
                else
                {
                    MessageBox.Show("Valitse kirjaus jota haluat muokata.");
                }

                Form1 NewForm = new Form1();
                NewForm.Show();
                this.Dispose(false);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Kirjoita kaikki tiedot  " + ex.Message);
            }

        }

        private List<BikeEntry> bikeEntries = new List<BikeEntry>();
        private DatabaseHelper dbHelper;

        public Form1() // tekee databasen
        {
            InitializeComponent();
            dbPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Database.db");
            dbHelper = new DatabaseHelper(dbPath);
            dbHelper.InitializeDatabase();
            LoadDatabaseContent();


        }


        private void LoadDatabaseContent() // lataa datan
        {
            bikeEntries.Clear();

            using (var connection = new SQLiteConnection(dbHelper.ConnectionString))
            {
                connection.Open();

                string selectQuery = "SELECT * FROM BikeEntries";

                using (var command = new SQLiteCommand(selectQuery, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read()) // lukee tiedostosta tiedot
                    {
                        BikeEntry entry = new BikeEntry
                        {
                            Id = Convert.ToInt32(reader["Id"]),
                            OwnerName = reader["OwnerName"].ToString(),
                            FrameNumber = Convert.ToDouble(reader["FrameNumber"]),
                            PhoneNumber = Convert.ToDouble(reader["PhoneNumber"]),
                            Email = reader["Email"].ToString(),
                            Price = Convert.ToDouble(reader["Price"])
                        };
                        bikeEntries.Add(entry);
                    }
                }
            }

            listBoxBikes.DataSource = bikeEntries;
            listBoxBikes.DisplayMember = "ToString";
        }


        private void buttontallenna_Click_1(object sender, EventArgs e) //tallentaa
        {
            try
            {
                string puhelin = txtpuhe.Text;
                string runko = txtnumero.Text;
                string hinta = txthinta.Text;
                string posti = txtsähkö.Text;
                string omistaja = txtomistaja.Text;

                Regex nimiReg = new Regex(@"^[a-zA-Z]*$");
                Regex numReg = new Regex(@"^[0-9]*$");

                if (!posti.Contains("@"))
                {
                    MessageBox.Show("Sähköposti ei kelpaa");
                    return;
                }

                if (!nimiReg.IsMatch(omistaja) && !numReg.IsMatch(hinta) && !numReg.IsMatch(puhelin) && !numReg.IsMatch(runko))
                {
                    BikeEntry entry = new BikeEntry
                    {
                        OwnerName = omistaja,
                        FrameNumber = Convert.ToDouble(runko),
                        PhoneNumber = Convert.ToDouble(puhelin),
                        Email = posti,
                        Price = Convert.ToDouble(hinta)
                    };


                    dbHelper.InsertBikeEntry(entry);
                    LoadDatabaseContent();

                    txthinta.Text = "";
                    txtnumero.Text = "";
                    txtpuhe.Text = "";
                    txtsähkö.Text = "";
                    txtomistaja.Text = "";

                    MessageBox.Show("Tiedot tallennettu onnistuneesti.");
                }
                else
                {
                    MessageBox.Show("bababa");
                    return;
                }




            }
            catch (Exception ex)
            {
                MessageBox.Show("Virhe tallennettaessa tietoja: " + ex.Message);
            }
            Form1 NewForm = new Form1();
            NewForm.Show();
            this.Dispose(false);
        }



        private void buttonpoista_Click(object sender, EventArgs e) // Poistaa
        {
            {
                if (listBoxBikes.SelectedItem is BikeEntry selectedEntry)
                {
                    DialogResult result = MessageBox.Show("Are you sure you want to delete this entry?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                    if (result == DialogResult.Yes)
                    {
                        dbHelper.DeleteBikeEntry(selectedEntry.Id);
                        LoadDatabaseContent();
                        MessageBox.Show("Entry deleted successfully.");
                    }
                }
                else
                {
                    MessageBox.Show("Please select an entry to delete.");
                }
                Form1 NewForm = new Form1();
                NewForm.Show();
                this.Dispose(false);
            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                buttontallenna.Visible = false;
                buttonmuokkaa.Visible = true;
                label2.Visible = true;

                txthinta.Visible = false;
                txtsähkö.Visible = false;
                txtnumero.Visible = false;
                txtomistaja.Visible = false;
                txtpuhe.Visible = false;

                txtmhinta.Visible = true;
                txtmsähkö.Visible = true;
                txtmnumero.Visible = true;
                txtmomistaja.Visible = true;
                txtmpuhe.Visible = true;
            }
            else
            {
                buttontallenna.Visible = true;

                buttonmuokkaa.Visible = false;
                label2.Visible = false;

                txthinta.Visible = true;
                txtsähkö.Visible = true;
                txtnumero.Visible = true;
                txtomistaja.Visible = true;
                txtpuhe.Visible = true;

                txtmhinta.Visible = false;
                txtmsähkö.Visible = false;
                txtmnumero.Visible = false;
                txtmomistaja.Visible = false;
                txtmpuhe.Visible = false;
            }
        }



        private void bntsalasana_Click(object sender, EventArgs e)
        {
            string salasana = txtsala.Text;
            if (string.Compare(salasana, "Kissa123", true) == 0)
            {
                checkBox1.Visible = true;
            }
            else
            {
                MessageBox.Show("Syötä oikea salasana salasana ja yritä uudelleen");
            }
        }
    }

    public class DatabaseHelper
    {
        public string ConnectionString { get; private set; }

        public DatabaseHelper(string dbPath)
        {
            ConnectionString = $"Data Source=|DataDirectory|{Path.GetFileName(dbPath)};Version=3;";
        }

        public void DeleteBikeEntry(int id)
        {
            using (var connection = new SQLiteConnection(ConnectionString))
            {
                connection.Open();

                string deleteQuery = "DELETE FROM BikeEntries WHERE Id = @Id";

                using (var command = new SQLiteCommand(deleteQuery, connection))
                {
                    command.Parameters.AddWithValue("@Id", id);
                    command.ExecuteNonQuery();
                }
            }
        }
        public void InitializeDatabase()
        {
            using (var connection = new SQLiteConnection(ConnectionString))
            {
                connection.Open();

                string createTableQuery = @"CREATE TABLE IF NOT EXISTS BikeEntries (
                    Id INTEGER PRIMARY KEY,
                    OwnerName TEXT,
                    FrameNumber REAL,
                    PhoneNumber REAL,
                    Email TEXT,
                    Price REAL
                )";

                using (var command = new SQLiteCommand(createTableQuery, connection))
                {
                    command.ExecuteNonQuery();
                }
            }
        }

        public void InsertBikeEntry(Form1.BikeEntry entry)
        {
            using (var connection = new SQLiteConnection(ConnectionString))
            {
                connection.Open();

                string insertQuery = @"INSERT INTO BikeEntries (OwnerName, FrameNumber, PhoneNumber, Email, Price)
                                      VALUES (@OwnerName, @FrameNumber, @PhoneNumber, @Email, @Price)";

                using (var command = new SQLiteCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@OwnerName", entry.OwnerName);
                    command.Parameters.AddWithValue("@FrameNumber", entry.FrameNumber);
                    command.Parameters.AddWithValue("@PhoneNumber", entry.PhoneNumber);
                    command.Parameters.AddWithValue("@Email", entry.Email);
                    command.Parameters.AddWithValue("@Price", entry.Price);

                    command.ExecuteNonQuery();
                }
            }
        }

        public void UpdateBikeEntry(Form1.BikeEntry entry)
        {
            using (var connection = new SQLiteConnection(ConnectionString))
            {
                connection.Open();

                string updateQuery = @"UPDATE BikeEntries SET 
                    OwnerName = @OwnerName,
                    FrameNumber = @FrameNumber,
                    PhoneNumber = @PhoneNumber,
                    Email = @Email,
                    Price = @Price
                    WHERE Id = @Id";

                using (var command = new SQLiteCommand(updateQuery, connection))
                {
                    command.Parameters.AddWithValue("@Id", entry.Id);
                    command.Parameters.AddWithValue("@OwnerName", entry.OwnerName);
                    command.Parameters.AddWithValue("@FrameNumber", entry.FrameNumber);
                    command.Parameters.AddWithValue("@PhoneNumber", entry.PhoneNumber);
                    command.Parameters.AddWithValue("@Email", entry.Email);
                    command.Parameters.AddWithValue("@Price", entry.Price);

                    command.ExecuteNonQuery();
                }
            }
        }


    }
}